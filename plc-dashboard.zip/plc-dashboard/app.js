const snap7 = require('node-snap7');
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const plc = new snap7.S7Client();
const PLC_IP = "192.168.0.1"; // Sostituisci con l'IP del tuo PLC
const PLC_RACK = 0;
const PLC_SLOT = 1;

// Connessione al PLC
plc.ConnectTo(PLC_IP, PLC_RACK, PLC_SLOT, function(err) {
    if (err) {
        console.error("Errore di connessione al PLC:", plc.ErrorText(err));
    } else {
        console.log("Connesso al PLC!");
    }
});

// Servire i file statici dalla cartella 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Route per la home page "/"
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API per leggere dati dal PLC
app.get('/plc/read', (req, res) => {
    plc.ReadArea(snap7.S7AreaDB, 1, 0, 2, snap7.S7WordLen.Byte, (err, data) => {
        if (err) {
            res.status(500).json({ error: plc.ErrorText(err) });
        } else {
            res.json({ byte1: data[0], byte2: data[1] });
        }
    });
});

// API per scrivere dati nel PLC (numero programma)
app.post('/plc/program', express.json(), (req, res) => {
    const programNumber = req.body.programNumber;
    const buffer = Buffer.from([programNumber]); // Imposta il numero del programma
    plc.WriteArea(snap7.S7AreaDB, 1, 0, 1, snap7.S7WordLen.Byte, buffer, (err) => {
        if (err) {
            res.status(500).json({ error: plc.ErrorText(err) });
        } else {
            res.json({ success: true });
        }
    });
});

// API per avviare il robot
app.post('/plc/start', express.json(), (req, res) => {
    const startSignal = Buffer.from([1]); // 1 per avviare
    plc.WriteArea(snap7.S7AreaDB, 1, 1, 1, snap7.S7WordLen.Byte, startSignal, (err) => {
        if (err) {
            res.status(500).json({ error: plc.ErrorText(err) });
        } else {
            res.json({ success: true });
        }
    });
});

// API per fermare il robot
app.post('/plc/stop', express.json(), (req, res) => {
    const stopSignal = Buffer.from([0]); // 0 per fermare
    plc.WriteArea(snap7.S7AreaDB, 1, 1, 1, snap7.S7WordLen.Byte, stopSignal, (err) => {
        if (err) {
            res.status(500).json({ error: plc.ErrorText(err) });
        } else {
            res.json({ success: true });
        }
    });
});

// WebSocket per aggiornamenti in tempo reale
wss.on('connection', (ws) => {
    console.log('Client connesso al WebSocket');
    setInterval(() => {
        plc.ReadArea(snap7.S7AreaDB, 1, 0, 2, snap7.S7WordLen.Byte, (err, data) => {
            if (!err) {
                ws.send(JSON.stringify({ byte1: data[0], byte2: data[1] }));
            }
        });
    }, 1000);
});

server.listen(3000, () => {
    console.log('Server avviato su http://localhost:3000');
});
